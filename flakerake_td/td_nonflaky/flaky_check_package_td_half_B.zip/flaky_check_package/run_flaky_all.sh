#!/bin/bash
# Flakiness check of the 48 generated tests: NIO, NonDex, iDFlakies, 100 reruns, then the summary.
# Usage (inside tmux, from anywhere):  bash <this folder>/run_flaky_all.sh
# Rerunning resumes; finished work is skipped.
D="$(cd "$(dirname "$0")" && pwd)"
S="$D/flaky_check_basic.py"
A="--tests $D/task_csvs/flaky_generated_tests.csv --archive-dir $D/extracted"

python3 $S nio       $A --nio-runs 100          2>&1 | tee "$D/flaky_nio.log"
python3 $S nondex    $A --nondex-runs 100       2>&1 | tee "$D/flaky_nondex.log"
python3 $S idflakies $A --rounds 20             2>&1 | tee "$D/flaky_idflakies.log"
python3 $S rerun     $A --runs 100 --offline    2>&1 | tee "$D/flaky_rerun.log"
python3 $S summary   $A
