#!/usr/bin/env python3
"""check_td_rows.py: READ-ONLY check of every row of a TD run before the long run starts.

Run it inside the package folder, after prepare_td_nonflaky.py and after the archives are set up:

    python3 check_td_rows.py task_csvs/td_main.csv

Why: flaky_check.py (v6) sets every row up with the class `Prepared` OUTSIDE its try/except. If one row's setup raises
(for example its focal_from_test file is not in the archive, or is found twice), the whole `flakerake` run stops with a
traceback at that row, hours into the run, and starting it again stops at the same row. This script runs exactly that
setup code (flaky_check.Prepared and the pom step of Prepared.__enter__) for every row, without building, running
Maven, copying tests or taking the lock, and tells you which rows would stop the run, before you start it.

What it checks per row (the same code the run uses):
  1. the row is supported (JDK 8 or 11) and its archive is extracted (a missing archive is information, not an error:
     night_run.py downloads it);
  2. Prepared(...) works (reads the generated test, finds the module through focal_from_test, finds the project root);
  3. the module pom exists and, for "mockito_fix" rows, replay_generated.mockito_fixed() works on it;
  4. the generated test classes do not already exist in the module (the run would stop that row: would_overwrite);
  5. the module pom has mockito-core (and mockito-junit-jupiter if the tests import it);
  6. the JDK of the row is installed.
It writes nothing in the package folder. It makes one temporary folder in /tmp and removes it at the end.
--write-safe-csv NEW.csv writes a copy of the CSV without the rows that would stop the run (refuses to overwrite).
Exit code: 0 = no row would stop the run, 2 = at least one would.

What it can NOT check: that the module builds, that the tests compile, that FlakeRake finds anything. That only the run shows.
"""
import argparse
import csv
import os
import re
import shutil
import sys
import tempfile
from collections import Counter
from pathlib import Path


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("tests", type=Path, help="e.g. task_csvs/td_main.csv")
    a.add_argument("--package-dir", type=Path, default=Path.cwd())
    a.add_argument("--archive-dir", type=Path, default=None, help="default: <package>/extracted")
    a.add_argument("--write-safe-csv", type=Path, default=None)
    args = a.parse_args()
    pkg = args.package_dir.resolve()
    for need in ("flaky_check.py", "night_run.py", "replay_generated.py"):
        if not (pkg / need).is_file():
            sys.exit(f"{pkg} is not the package folder ({need} missing). cd into it or use --package-dir.")
    if not args.tests.is_file():
        sys.exit(f"{args.tests} not found")
    sys.path.insert(0, str(pkg))
    import flaky_check as F  # noqa: E402  (the package's own code, the same the run uses)
    B, R = F.B, F.R

    tmp = Path(tempfile.mkdtemp(prefix="check_td_rows_"))
    ns = argparse.Namespace(tests=args.tests.resolve(), only=[], command="flakerake",
                            archive_dir=[(args.archive_dir or pkg / "extracted").resolve()],
                            out=tmp, env=os.environ.copy())
    try:
        rows = F.load_tests(ns)
        print(f"{len(rows)} rows, {sum(len(r[2]['methods']) for r in rows)} test methods from {args.tests.name}\n")
        status = {}   # rid -> "ok" | "info" | "stops_row" | "stops_run"
        notes = {}
        for rid, root, g, m, fix in rows:
            n = []
            st = "ok"
            reason = F.flakerake_unsupported(g, m)
            if reason:
                status[rid], notes[rid] = "info", [f"not supported ({reason}): the run marks it and goes on"]
                continue
            if root is None:
                status[rid], notes[rid] = "info", [f"archive {g['zip']} is not extracted yet: night_run.py downloads it first. "
                                                   "Run this check again after that"]
                continue
            if not (root / ".batch_extracted").is_file():
                n.append("archive folder has no .batch_extracted marker (setup_archives.py did not finish?)")
                st = "stops_row"
            try:
                p = F.Prepared(rid, root, g, m, fix, ns)
            except Exception as ex:  # the run does not catch this: it would stop
                status[rid] = "stops_run"
                notes[rid] = [f"WOULD STOP THE WHOLE RUN: {type(ex).__name__}: {str(ex)[:300]}"]
                continue
            if not p.pom.is_file():
                status[rid], notes[rid] = "stops_run", [f"WOULD STOP THE WHOLE RUN: module pom missing: {p.pom}"]
                continue
            pom_text = p.pom.read_text(encoding="utf-8", errors="replace")
            if fix:
                try:
                    R.mockito_fixed(pom_text, g["chatunitest_mode"])
                except Exception as ex:
                    status[rid] = "stops_run"
                    notes[rid] = [f"WOULD STOP THE WHOLE RUN: mockito fix on the pom fails: {type(ex).__name__}: {ex}"]
                    continue
            conflicts = []
            for _, pkgname, name in p.files:
                dest = p.module_dir / "src" / "test" / "java" / Path(*pkgname.split(".")) / (name + ".java")
                if dest.exists() and not (p.row_dir / "copied.txt").is_file():
                    conflicts.append(str(dest))
            if conflicts:
                n.append("would_overwrite (this row is skipped, the run goes on): " + "; ".join(conflicts))
                st = "stops_row"
            if "mockito-core" not in pom_text and not fix:
                n.append("module pom has no mockito-core (setup_archives.py adds it): the tests may not compile")
                st = "stops_row" if st == "ok" else st
            imports_jupiter = any("org.mockito.junit.jupiter" in f.read_text(encoding="utf-8", errors="replace")
                                  for f in g["test_files"])
            if imports_jupiter and "mockito-junit-jupiter" not in pom_text and not fix:
                n.append("tests import mockito-junit-jupiter but the pom has none: they may not compile")
                st = "stops_row" if st == "ok" else st
            java = str(m["java"]).strip()
            jdk = B.find_jdk(java)
            if not jdk or not (Path(jdk) / "bin" / "java").exists():
                n.append(f"no JDK {java} found (set JAVA_HOME_{java}): the row would end flakerake_did_not_run")
                st = "stops_row" if st == "ok" else st
            status[rid], notes[rid] = st, n

        c = Counter(status.values())
        bad_run = sorted(r for r, s in status.items() if s == "stops_run")
        bad_row = sorted(r for r, s in status.items() if s == "stops_row")
        info = sorted(r for r, s in status.items() if s == "info")
        for title, ids in (("ROWS THAT WOULD STOP THE WHOLE RUN", bad_run), ("rows the run would skip or that may not compile", bad_row),
                           ("information", info)):
            if ids:
                print(f"== {title} ({len(ids)})")
                for r in ids:
                    zipname = next(x[2]["zip"] for x in rows if x[0] == r)
                    print(f"  {r}  [{zipname}]")
                    for line in notes[r]:
                        print("      " + line)
                print()
        print(f"SUMMARY: ok {c['ok']} | would stop the whole run {c['stops_run']} | skipped or may not compile {c['stops_row']} "
              f"| information {c['info']} | rows {len(rows)}")
        if args.write_safe_csv:
            if args.write_safe_csv.exists():
                sys.exit(f"{args.write_safe_csv} exists, not overwritten")
            keep = set(bad_run)
            out_rows, kept, dropped = [], 0, 0
            reader = csv.DictReader(open(args.tests, encoding="utf-8", newline=""))
            fields = reader.fieldnames
            for r in reader:
                src = (pkg / r["test_file"]).resolve()
                run_dir = next((q for q in src.parents if q.name.startswith("row_")), src.parent)
                rid = f"{run_dir.parent.parent.name}_{run_dir.name}"
                if rid in keep:
                    dropped += 1
                else:
                    out_rows.append(r)
                    kept += 1
            with open(args.write_safe_csv, "w", encoding="utf-8", newline="") as f:
                w = csv.DictWriter(f, fieldnames=fields, lineterminator="\n")
                w.writeheader()
                w.writerows(out_rows)
            print(f"{args.write_safe_csv}: {kept} methods kept, {dropped} methods of the rows that would stop the run left out")
        if bad_run:
            print("\nDO NOT START THE LONG RUN WITH THIS CSV AS IT IS: " + ", ".join(bad_run))
            return 2
        print("\nNo row would stop the whole run. (This does not prove the tests compile or that FlakeRake finds anything.)")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
