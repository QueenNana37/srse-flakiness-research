# TD (FlakeRake) check, half B: 75 test methods on JDK 8

This is the flaky check package v6 (FlakeRake integration) with half of Suzzana's non flaky generated tests
(`td_nonflaky_tests_package.zip`, main set). The other half runs on Hana's machine. Nothing in the package code was changed.

## Run it (one command)

Needs (Linux or WSL, Ubuntu tested pattern): python3, Maven, curl, unzip, **JDK 8 with javac** (`sudo apt install openjdk-8-jdk`),
about 20 GB free disk, internet (Zenodo and Maven Central). Not needed: JDK 11, protoc.

```
unzip flaky_check_package_td_half_B.zip
cd flaky_check_package
bash run_td_half.sh --check-only      # optional first try: tools, download of 6 archives, check of every row, then stops
bash run_td_half.sh                   # the whole thing (starts tmux itself)
```

It runs the controls first (tiny tests with a known race, JDK 8, JUnit 4 and 5: each up to about 1.5 h), then the 37 rows.
Expected time: about 42 hours (estimate from Hana's earlier run, see below) plus up to 3 h for the controls and the downloads.

- Stop: Ctrl+C is safe. Start `bash run_td_half.sh` again: finished methods are kept, nothing is deleted or overwritten.
- Watch: `tail -f night_out/flakerake_main_*.log`, or `python3 night_run.py --tests task_csvs/td_main_B.csv --report-only`.
- The run stops itself after 60 hours; start it again to continue.
- Keep the machine awake and, if you can, not busy with other heavy work: FlakeRake works by delaying threads, timing matters.

## What to send back when it ends

`NIGHT_REPORT.txt` and `flaky_check_out/flakerake_results.csv` (and `td_run.log` if something looks wrong).
Per method: `td` = true (FlakeRake found a sleep placement that makes the test fail), false (no failure found; with
"NOTHING WAS SLOWED" in the detail the false says little), inconclusive, timeout, error.

## If something stops

`run_td_half.sh` prints `STOP: ...` with the reason before the long run starts. Send that output to Hana.
The controls print AS EXPECTED / NOT AS EXPECTED; NOT AS EXPECTED means do not trust `false` results from this machine.

## Facts and estimates

- 75 methods in 37 rows, 6 archives: CAMEL-12025, eco-schema-catalog store, elasticjobf0d, marineapi, ormlitecore, shardingsphere elasticjob-lite-core 23a2ab5.
- Defaults as in all earlier runs: 5 FlakeRake runs, 10 s sleep, 2 h cap per method.
- Time estimate: JDK 8 methods took 32.5 minutes on average in Hana's run of 27 Oct (22 methods, range 1 to 56 minutes), one method (CAMEL) hits the 2 h cap:
  74 x 32.5 min + 2 h = about 42 h. A different machine can be faster or slower.
- Full details of the tool: `README_flakerake.md` and `flakerake/PATCHES.md`.
