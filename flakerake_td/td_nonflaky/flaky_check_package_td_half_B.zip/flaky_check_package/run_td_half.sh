#!/bin/bash
# run_td_half.sh: ONE command for this half of the TD (FlakeRake) check on non flaky generated tests.
#
#   bash run_td_half.sh                 does everything below, inside tmux (it starts tmux itself if it is installed)
#   bash run_td_half.sh --check-only    does steps 1-4 only and stops before the long run (good as a first try)
#
# Steps (nothing is deleted or overwritten; a second start continues where the first stopped):
#   1. checks the tools: python3, Maven, curl, unzip, a JDK 8 with javac (and JDK 11 if this half has JDK 11 rows)
#   2. downloads and sets up the archives this half needs (package scripts download_zips.sh and setup_archives.py;
#      an archive that is already set up is skipped)
#   3. check_td_rows.py: runs the package's own row setup on every row without running anything, and stops here if a
#      row would stop the whole run
#   4. (--check-only stops here)
#   5. night_run.py: JDK controls, then FlakeRake on every row of this half. Ctrl+C is safe; start this script again to continue.
# Results: NIGHT_REPORT.txt and flaky_check_out/flakerake_results.csv. See README_RUN.md.
cd "$(dirname "$0")" || exit 1
CSV=task_csvs/td_main_B.csv
CHECK_ONLY=0
for a in "$@"; do
  case "$a" in
    --check-only) CHECK_ONLY=1 ;;
    --inner) ;;
    *.csv) CSV="$a" ;;
    *) echo "unknown argument: $a"; exit 1 ;;
  esac
done
[ -f "$CSV" ] || { echo "STOP: $CSV not found (run this from the unzipped flaky_check_package folder)"; exit 1; }

# tmux: the run takes many hours, so run inside tmux (survives closing the terminal). Only when attached to a terminal.
if [ -z "$TMUX" ] && [ "$CHECK_ONLY" = 0 ] && [[ " $* " != *" --inner "* ]] && command -v tmux > /dev/null 2>&1 && [ -t 0 ]; then
  if tmux has-session -t td_half 2> /dev/null; then
    echo "STOP: a tmux session called td_half already exists (a run may be going). Look at it with: tmux attach -t td_half"
    exit 1
  fi
  echo "Starting a tmux session called td_half. Detach with Ctrl+b then d; get back with: tmux attach -t td_half"
  exec tmux new-session -s td_half "bash '$PWD/run_td_half.sh' --inner $CSV; echo; echo 'Finished or stopped. Press Enter to close.'; read"
fi
[ -z "$TMUX" ] && [ "$CHECK_ONLY" = 0 ] && ! command -v tmux > /dev/null 2>&1 && \
  echo "NOTE: tmux is not installed. The run needs many hours: do not close this terminal (or install tmux and start again)."

echo "=== 1. tools ==="
for t in python3 mvn curl unzip; do
  command -v "$t" > /dev/null 2>&1 || { echo "STOP: $t is not installed"; exit 1; }
done
JDKS=$(python3 - "$CSV" <<'EOF'
import csv, sys
print(" ".join(sorted({r["java"].strip() for r in csv.DictReader(open(sys.argv[1], encoding="utf-8"))})))
EOF
)
for v in 8 $JDKS; do
  python3 - "$v" <<'EOF' || exit 1
import sys
from pathlib import Path
sys.path.insert(0, ".")
import batch_reproflake_chatunitest as B
v = sys.argv[1]
jdk = B.find_jdk(v)
if not jdk or not (Path(jdk) / "bin" / "javac").exists():
    sys.exit(f"STOP: no JDK {v} with javac found. Install it (Ubuntu: sudo apt install openjdk-{v}-jdk) or set JAVA_HOME_{v}.")
print(f"JDK {v}: {jdk}")
EOF
done
echo "rows of this half need JDK $JDKS; JDK 8 with javac is always needed to build the FlakeRake agent"

echo "=== 2. archives ==="
ZIPS=$(python3 - "$CSV" <<'EOF'
import csv, sys
seen = []
for r in csv.DictReader(open(sys.argv[1], encoding="utf-8")):
    if r["zip"] not in seen:
        seen.append(r["zip"])
print("\n".join(seen))
EOF
)
while IFS= read -r z; do
  [ -n "$z" ] || continue
  if [ -f "extracted/$z/.batch_extracted" ] && [ -f "extracted/$z/.batch_m2_seeded" ]; then
    echo "[$z] already set up"
    continue
  fi
  echo "[$z] downloading and setting up"
  bash download_zips.sh "$z" || { echo "STOP: download of $z failed. Run this script again (it resumes)."; exit 1; }
  python3 setup_archives.py --only "$z" || { echo "STOP: setup of $z failed, see the output above."; exit 1; }
done <<< "$ZIPS"

echo "=== 3. check of every row ==="
python3 check_td_rows.py "$CSV" || { echo "STOP: see above. Do not start the long run; send this output to Hana."; exit 1; }

if [ "$CHECK_ONLY" = 1 ]; then
  echo "=== --check-only: stopping before the long run. Start it with: bash run_td_half.sh ==="
  exit 0
fi

echo "=== 5. the run (many hours) ==="
python3 night_run.py --tests "$CSV" 2>&1 | tee -a td_run.log
code=${PIPESTATUS[0]}
echo
echo "Run ended with exit code $code. Send: NIGHT_REPORT.txt and flaky_check_out/flakerake_results.csv"
echo "If it was stopped (Ctrl+C, power, 60 hour limit): start 'bash run_td_half.sh' again, finished methods are kept."
exit "$code"
