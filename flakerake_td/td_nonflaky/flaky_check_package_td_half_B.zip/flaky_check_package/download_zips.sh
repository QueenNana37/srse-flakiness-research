#!/bin/bash
# Downloads the archives listed in archives.csv into zips/ with curl: resumes an interrupted
# download, checks the size against the server's Content-Length and that the zip is readable.
# Usage (from anywhere):  bash download_zips.sh            all 15 archives
#                         bash download_zips.sh marineapi  only archives whose name contains "marineapi"
# Run setup_archives.py afterwards: it finds the finished zips and only extracts them.
cd "$(dirname "$0")" || exit 1
mkdir -p zips
bad=0
while IFS=, read -r name url; do
  name=${name//$'\r'/}; url=${url//$'\r'/}
  [ "$name" = "zip" ] && continue
  [ -n "$name" ] || continue
  if [ -n "$1" ] && [[ "$name" != *"$1"* ]]; then continue; fi
  dest="zips/$name.zip"
  ok=0
  for try in 1 2 3 4 5 6; do
    size=$(curl -sSIL --connect-timeout 30 "$url" < /dev/null | tr -d '\r' | awk 'tolower($1)=="content-length:" {s=$2} END {print s}')
    have=$(stat -c %s "$dest" 2>/dev/null || echo 0)
    if [ -n "$size" ] && [ "$have" = "$size" ] && unzip -tq "$dest" > /dev/null 2>&1; then ok=1; break; fi
    # server gave no size: keep a zip that is readable
    if [ -z "$size" ] && [ "$have" -gt 0 ] && unzip -tq "$dest" > /dev/null 2>&1; then ok=1; break; fi
    if [ -n "$size" ] && [ "$have" -gt "$size" ]; then rm -f "$dest"; fi
    curl -sSL -C - --connect-timeout 30 --speed-limit 1000 --speed-time 60 -o "$dest" "$url" < /dev/null
    [ $? -eq 33 ] && rm -f "$dest"
  done
  if [ "$ok" = 1 ]; then echo "OK  $name ($(stat -c %s "$dest") bytes)"; else echo "BAD $name"; bad=1; fi
done < archives.csv
[ "$bad" = 0 ] && echo "All requested archives downloaded." || echo "Some archives are BAD: run this script again (it resumes)."
exit $bad
